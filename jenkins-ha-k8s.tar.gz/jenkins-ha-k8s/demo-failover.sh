#!/usr/bin/env bash
# demo-failover.sh — Demonstrates Jenkins HA failover.
# Kills the active pod and watches the standby take over.
#
# This is the script to run during your demo to prove:
#   1. Only one active Jenkins instance at any time
#   2. Failover within 30 seconds
#   3. Stable storage (Jenkins state survives the failover)

set -uo pipefail

NS="jenkins"
LEASE="jenkins-leader"

# ── Colors ───────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

log()  { echo -e "${CYAN}[$(date -u '+%H:%M:%S')]${NC} $*"; }
ok()   { echo -e "${GREEN}  ✓${NC} $*"; }
warn() { echo -e "${YELLOW}  ⚠${NC} $*"; }
fail() { echo -e "${RED}  ✗${NC} $*"; }

divider() {
  echo ""
  echo -e "${BOLD}═══════════════════════════════════════════════════════════${NC}"
  echo -e "${BOLD}  $1${NC}"
  echo -e "${BOLD}═══════════════════════════════════════════════════════════${NC}"
  echo ""
}

# ── Pre-flight ───────────────────────────────────────────────────────────────
divider "JENKINS HA FAILOVER DEMO"

log "Pre-flight checks..."

if ! kubectl -n "$NS" get statefulset jenkins &>/dev/null; then
  fail "StatefulSet 'jenkins' not found in namespace '$NS'."
  echo "  Run ./deploy.sh first."
  exit 1
fi

# ── Step 1: Show current state ───────────────────────────────────────────────
divider "STEP 1 — Current State (Before Failure)"

log "Pod status:"
kubectl -n "$NS" get pods -l app=jenkins -L jenkins-role -o wide
echo ""

ACTIVE_POD=$(kubectl -n "$NS" get pod -l app=jenkins,jenkins-role=active \
  -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)
STANDBY_POD=$(kubectl -n "$NS" get pod -l app=jenkins,jenkins-role=standby \
  -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)

if [ -z "$ACTIVE_POD" ]; then
  fail "No active pod found. Wait for the system to stabilize."
  exit 1
fi

ok "Active pod:  ${BOLD}${ACTIVE_POD}${NC}"
ok "Standby pod: ${BOLD}${STANDBY_POD}${NC}"
echo ""

log "Lease state:"
kubectl -n "$NS" get lease "$LEASE" \
  -o jsonpath='  Holder: {.spec.holderIdentity}   Renew: {.spec.renewTime}'
echo ""
echo ""

log "Service endpoints (only active pod should be listed):"
kubectl -n "$NS" get endpoints jenkins
echo ""

# Verify only one pod is active
ACTIVE_COUNT=$(kubectl -n "$NS" get pods -l app=jenkins,jenkins-role=active \
  --no-headers 2>/dev/null | wc -l)
if [ "$ACTIVE_COUNT" -eq 1 ]; then
  ok "VERIFIED: Exactly 1 active Jenkins instance"
else
  fail "Expected 1 active pod, found $ACTIVE_COUNT"
fi

# ── Step 2: Create a marker file to prove storage persistence ────────────────
divider "STEP 2 — Create Marker File (Prove Storage Survives)"

MARKER_VALUE="demo-$(date +%s)"
log "Writing marker file to Jenkins home on active pod..."
log "  Value: ${MARKER_VALUE}"

kubectl -n "$NS" exec "$ACTIVE_POD" -c jenkins -- \
  bash -c "echo '${MARKER_VALUE}' > /var/jenkins_home/HA_DEMO_MARKER.txt" 2>/dev/null

# Verify it was written
READBACK=$(kubectl -n "$NS" exec "$ACTIVE_POD" -c jenkins -- \
  cat /var/jenkins_home/HA_DEMO_MARKER.txt 2>/dev/null || echo "FAILED")

if [ "$READBACK" = "$MARKER_VALUE" ]; then
  ok "Marker file written and verified on ${ACTIVE_POD}"
else
  fail "Failed to write marker file"
fi

echo ""
log "Also verifying the standby pod can see the same PVC data..."
STANDBY_READ=$(kubectl -n "$NS" exec "$STANDBY_POD" -c jenkins -- \
  cat /var/jenkins_home/HA_DEMO_MARKER.txt 2>/dev/null || echo "FAILED")

if [ "$STANDBY_READ" = "$MARKER_VALUE" ]; then
  ok "Standby pod can read the same marker (shared RWX PVC confirmed)"
else
  warn "Standby could not read marker (may not have volume mounted yet)"
fi

# ── Step 3: Kill the active pod ──────────────────────────────────────────────
divider "STEP 3 — Simulating Failure (Deleting Active Pod)"

log "Deleting active pod: ${BOLD}${ACTIVE_POD}${NC}"
echo ""
echo -e "${RED}  >>> KILLING ${ACTIVE_POD} NOW <<<${NC}"
echo ""

KILL_TIME=$(date +%s)
kubectl -n "$NS" delete pod "$ACTIVE_POD" --grace-period=0 --force 2>/dev/null &
DELETE_PID=$!

# ── Step 4: Watch the failover ───────────────────────────────────────────────
divider "STEP 4 — Watching Failover (Target: ≤30 seconds)"

log "Monitoring for standby promotion..."
echo ""

FAILOVER_DETECTED=false
FAILOVER_TIME=0

for i in $(seq 1 40); do
  ELAPSED=$(( $(date +%s) - KILL_TIME ))

  # Check if the former standby is now active
  NEW_ACTIVE=$(kubectl -n "$NS" get pod -l app=jenkins,jenkins-role=active \
    -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)

  # Get current lease holder
  HOLDER=$(kubectl -n "$NS" get lease "$LEASE" \
    -o jsonpath='{.spec.holderIdentity}' 2>/dev/null || echo "???")

  # Pod statuses
  POD_STATUS=$(kubectl -n "$NS" get pods -l app=jenkins -L jenkins-role \
    --no-headers 2>/dev/null || echo "checking...")

  echo -e "${CYAN}  [+${ELAPSED}s]${NC} Lease holder: ${BOLD}${HOLDER}${NC}"
  echo "$POD_STATUS" | while read -r line; do
    echo "         $line"
  done

  if [ -n "$NEW_ACTIVE" ] && [ "$NEW_ACTIVE" != "$ACTIVE_POD" ]; then
    FAILOVER_TIME=$ELAPSED
    FAILOVER_DETECTED=true
    echo ""
    ok "FAILOVER COMPLETE in ${BOLD}${FAILOVER_TIME} seconds${NC}!"
    ok "New active pod: ${BOLD}${NEW_ACTIVE}${NC}"
    break
  fi

  echo ""
  sleep 2
done

wait $DELETE_PID 2>/dev/null || true

if [ "$FAILOVER_DETECTED" = false ]; then
  fail "Failover did not complete within 80 seconds. Check sidecar logs."
  echo ""
  echo "Debug commands:"
  echo "  kubectl -n $NS logs jenkins-0 -c leader-elector --tail=30"
  echo "  kubectl -n $NS logs jenkins-1 -c leader-elector --tail=30"
  exit 1
fi

# ── Step 5: Verify the new leader ────────────────────────────────────────────
divider "STEP 5 — Post-Failover Verification"

NEW_ACTIVE=$(kubectl -n "$NS" get pod -l app=jenkins,jenkins-role=active \
  -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)

log "Checking single-leader invariant..."
ACTIVE_COUNT=$(kubectl -n "$NS" get pods -l app=jenkins,jenkins-role=active \
  --no-headers 2>/dev/null | wc -l)
if [ "$ACTIVE_COUNT" -eq 1 ]; then
  ok "VERIFIED: Exactly 1 active Jenkins instance (no split-brain)"
else
  fail "Expected 1 active pod, found $ACTIVE_COUNT"
fi

echo ""
log "Lease state:"
kubectl -n "$NS" get lease "$LEASE" \
  -o jsonpath='  Holder: {.spec.holderIdentity}   Renew: {.spec.renewTime}'
echo ""
echo ""

log "Service endpoints:"
kubectl -n "$NS" get endpoints jenkins
echo ""

# ── Step 6: Verify storage survived ─────────────────────────────────────────
divider "STEP 6 — Storage Persistence Verification"

log "Reading marker file from new active pod (${NEW_ACTIVE})..."

# Give it a moment for the volume to be mounted
sleep 3

FINAL_READ=$(kubectl -n "$NS" exec "$NEW_ACTIVE" -c jenkins -- \
  cat /var/jenkins_home/HA_DEMO_MARKER.txt 2>/dev/null || echo "FAILED")

if [ "$FINAL_READ" = "$MARKER_VALUE" ]; then
  ok "VERIFIED: Marker file survived failover!"
  ok "  Written value:  ${MARKER_VALUE}"
  ok "  Read back value: ${FINAL_READ}"
else
  if [ "$FINAL_READ" = "FAILED" ]; then
    warn "Could not read marker yet (Jenkins container may still be starting)"
    warn "Try manually: kubectl -n $NS exec $NEW_ACTIVE -c jenkins -- cat /var/jenkins_home/HA_DEMO_MARKER.txt"
  else
    fail "Marker mismatch! Written: ${MARKER_VALUE}, Got: ${FINAL_READ}"
  fi
fi

# ── Summary ──────────────────────────────────────────────────────────────────
divider "DEMO RESULTS"

echo -e "  ${BOLD}1. Single Active Instance:${NC}"
if [ "$ACTIVE_COUNT" -eq 1 ]; then
  echo -e "     ${GREEN}✓ PASS${NC} — Only one Jenkins pod was active at all times"
else
  echo -e "     ${RED}✗ FAIL${NC}"
fi

echo ""
echo -e "  ${BOLD}2. Failover Speed:${NC}"
if [ "$FAILOVER_TIME" -le 30 ]; then
  echo -e "     ${GREEN}✓ PASS${NC} — Failover completed in ${FAILOVER_TIME}s (target: ≤30s)"
else
  echo -e "     ${YELLOW}⚠ SLOW${NC} — Failover took ${FAILOVER_TIME}s (target: ≤30s)"
fi

echo ""
echo -e "  ${BOLD}3. Stable Storage:${NC}"
if [ "$FINAL_READ" = "$MARKER_VALUE" ]; then
  echo -e "     ${GREEN}✓ PASS${NC} — Data persisted across failover"
else
  echo -e "     ${YELLOW}⚠ PENDING${NC} — Verify manually after Jenkins starts"
fi

echo ""
echo -e "${BOLD}═══════════════════════════════════════════════════════════${NC}"
echo ""

# ── Wait for the replacement pod ─────────────────────────────────────────────
log "Waiting for Kubernetes to recreate the deleted pod..."
log "(StatefulSet will bring it back as a new standby)"
echo ""

for i in $(seq 1 12); do
  POD_COUNT=$(kubectl -n "$NS" get pods -l app=jenkins --no-headers 2>/dev/null | wc -l)
  if [ "$POD_COUNT" -ge 2 ]; then
    ok "Both pods running again:"
    kubectl -n "$NS" get pods -l app=jenkins -L jenkins-role
    break
  fi
  sleep 5
done

echo ""
log "Demo complete. To access Jenkins:"
echo "    kubectl -n jenkins port-forward svc/jenkins 8080:8080"
echo "    Then open: http://localhost:8080"
